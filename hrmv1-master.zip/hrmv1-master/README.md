Flutter Firebase Heart Rate Monitoring Application
