import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_auth/models/call.dart';

import 'package:flutter_auth/resources/call_methods.dart';
import 'package:flutter_auth/screens/callscreens/pickup/pickup_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PickupLayout extends StatefulWidget {
  final Widget scaffold;

  PickupLayout({
    @required this.scaffold,
  });

  @override
  _PickupLayoutState createState() => _PickupLayoutState();
}

class _PickupLayoutState extends State<PickupLayout> {
  final CallMethods callMethods = CallMethods();
  final _auth = FirebaseAuth.instance;
  User loggedInUser;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCurrentUser();
  }

  void getCurrentUser() async {
    try {
      final user = _auth.currentUser;

      if (user != null) {
        setState(() {
          loggedInUser = user;
        });
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return (loggedInUser != null && loggedInUser.email != null)
        ? StreamBuilder<DocumentSnapshot>(
            stream: callMethods.callStream(email: loggedInUser.email),
            builder: (context, snapshot) {
              if (snapshot.hasData && snapshot.data.data() != null) {
                Call call = Call.fromMap(snapshot.data.data());

                if (!call.hasDialled) {
                  return PickupScreen(call: call);
                }
              }
              return widget.scaffold;
            },
          )
        : Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
  }
}
