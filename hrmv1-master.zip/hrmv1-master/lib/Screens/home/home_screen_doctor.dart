import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_auth/Screens/Login/components/background.dart';
import 'package:flutter_auth/components/rounded_button.dart';
import 'package:flutter_auth/constants.dart';
import 'package:flutter_auth/Screens/home/chat.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_auth/models/customUser.dart';
import 'package:flutter_auth/Screens/callscreens/pickup/pickup_layout.dart';
import 'package:flutter_auth/utils/call_utilities.dart';

// ignore: camel_case_types
class HomeScreenDoctor extends StatefulWidget {
  HomeScreenDoctor({Key key}) : super(key: key);

  @override
  _HomeScreenDoctorState createState() => _HomeScreenDoctorState();
}

// ignore: camel_case_types
class _HomeScreenDoctorState extends State<HomeScreenDoctor> {
  final _auth = FirebaseAuth.instance;
  final _fireStore = FirebaseFirestore.instance;
  CustomUser user;
  CustomUser senderUser;
  String bpm;
  String email2;
  CustomUser receiverUser;

  var patients = [];
  Map<String, String> patientsData = {};

  User loggedInUser;

  @override
  void initState() {
    // ignore: todo
    // TODO: implement initState
    super.initState();
    getCurrentUser();
  }

  void getCurrentUser() async {
    try {
      final user = _auth.currentUser;

      if (user != null) {
        loggedInUser = user;
        getPatientsData();
        checkPatientStatus();
      }
    } catch (e) {
      print(e);
    }
  }

  void getPatientsData() async {
    _fireStore
        .collection("usersData")
        .where("subscribed to", isEqualTo: loggedInUser.email)
        .snapshots()
        .listen((data) {
      for (int i = 0; i < data.size; i++) {
        patients.add(data.docs[i]["email"]);
        getPatientHrm(data.docs[i]["email"]);
        setState(() {
          email2 = data.docs[i]["email"];
        });
      }
      print(patients);
    });
  }

  void getPatientHrm(String emailId) async {
    _fireStore.collection("usersData").doc(emailId).snapshots().listen((data) {
      print(data.data()["userBpm"]);
      setState(() {
        patientsData[emailId] = data.data()["userBpm"];
        bpm = patientsData[emailId];
        print(bpm);
      });
    });
  }

  void createChatRoom(String chatRoomId, email1, email2) async {
    await _fireStore.collection("chatroom").doc(chatRoomId).set(email1, email2);
  }

  void sendMessage(String email1, String email2) {
    user = CustomUser(email: email2);

    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => Chat(
                  chatRoomId: email1 + "_" + email2,
                  myEmail: email1,
                  email2: email2,
                  receiver: user,
                )));
  }

  void checkPatientStatus() async {
    _fireStore
        .collection("usersData")
        .where("subscribed to", isEqualTo: loggedInUser.email)
        .snapshots()
        .listen((data) {
      for (int i = 0; i < data.size; i++) {
        if (data.docs[i]["makeContact"] == true) {
          showAlertDialog(context);
        } else {
          print("makeContact is likely to be null");
        }
      }
    });
  }

  showAlertDialog(BuildContext context) {
    senderUser = CustomUser(email: loggedInUser.email);
    receiverUser = CustomUser(email: email2);
    print(email2);
    // set up the buttons
    Widget cancelButton = FlatButton(
      child: Text("Cancel"),
      onPressed: () async {
        await _fireStore
            .collection("usersData")
            .doc(email2)
            .update({"makeContact": false});
        Navigator.pop(context);
      },
    );
    Widget continueButton = FlatButton(
      child: Text("Yes"),
      onPressed: () async {
        await CallUtils.dialVoice(
          from: senderUser,
          to: receiverUser,
          context: context,
        );
        await _fireStore
            .collection("usersData")
            .doc(email2)
            .update({"makeContact": false});
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Alert"),
      content: Text("Patient " +
          email2 +
          " is expecting a call from you. Do you want to make a call?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return PickupLayout(
        scaffold: Scaffold(
      body: Background(
          child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Welcome",
              style: TextStyle(fontSize: 50.0, fontWeight: FontWeight.w100),
            ),
            SizedBox(height: 20),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  "Doctor Dashboard",
                  style: TextStyle(fontSize: 34, color: kPrimaryColor),
                  textAlign: TextAlign.center,
                ),
                ListView.builder(
                    shrinkWrap: true,
                    itemCount: patientsData.length,
                    itemBuilder: (BuildContext context, int index) {
                      String key = patientsData.keys.elementAt(index);
                      return new Column(
                        children: <Widget>[
                          new ListTile(
                              title: new Text("$key"),
                              subtitle: new Text("${patientsData[key]}"),
                              trailing: IconButton(
                                  icon: Icon(Icons.message),
                                  onPressed: () =>
                                      sendMessage(loggedInUser.email, key))),
                          new Divider(
                            height: 2.0,
                          ),
                        ],
                      );
                    }),
              ],
            ),
            SizedBox(height: 20),
            RoundedButton(
              text: "Log out",
              press: () {
                _auth.signOut();
                Navigator.pop(context);
              },
            )
          ],
        ),
      )),
    ));
  }
}
