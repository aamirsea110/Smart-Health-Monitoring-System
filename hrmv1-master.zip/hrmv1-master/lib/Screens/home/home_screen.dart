import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_auth/Screens/Login/components/background.dart';
import 'package:flutter_auth/Screens/home/subscribedChat.dart';
import 'package:flutter_auth/components/rounded_button.dart';
import 'package:flutter_auth/constants.dart';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:async';
import 'package:flutter_auth/Screens/callscreens/pickup/pickup_layout.dart';

// ignore: camel_case_types
class homeScreen extends StatefulWidget {
  homeScreen({Key key}) : super(key: key);

  @override
  _homeScreenState createState() => _homeScreenState();
}

// ignore: camel_case_types
class _homeScreenState extends State<homeScreen> {
  final _auth = FirebaseAuth.instance;
  final _fireStore = FirebaseFirestore.instance;

  String bpm = "0";
  User loggedInUser;
  int selectedRadio;
  String byDefaultSubscription;
  String subscribedDoctor;
  Timer _timer;
  //bluetooth
  FlutterBluetoothSerial _bluetooth = FlutterBluetoothSerial.instance;
  BluetoothConnection connection;
  BluetoothDevice mydevice;
  String op = "0";
  bool isConnectButtonEnabled = true;
  bool isDisConnectButtonEnabled = false;

  var doctors = [];

  void _connect() async {
    List<BluetoothDevice> devices = [];
    setState(() {
      isConnectButtonEnabled = false;
      isDisConnectButtonEnabled = true;
    });
    devices = await _bluetooth.getBondedDevices();
    // ignore: unnecessary_statements
    devices.forEach((device) {
      print(device);
      if (device.name == "HC-05") {
        mydevice = device;
      }
    });

    await BluetoothConnection.toAddress(mydevice.address).then((_connection) {
      print('Connected to the device');

      connection = _connection;
    });

    connection.input.listen((Uint8List data) {
      print('Arduino Data : ${ascii.decode(data)}');
      setState(() {
        op = ascii.decode(data);
      });
    });

    connection.input.listen(null).onDone(() {
      print('Disconnected remotely!');
    });
  }

  void setSelectedRadio(int val) {
    setState(() {
      selectedRadio = val;
    });
  }

  void _disconnect() {
    setState(() {
      op = "Disconnected";
      isConnectButtonEnabled = true;
      isDisConnectButtonEnabled = false;
    });
    connection.close();
    connection.dispose();
  }

  @override
  void initState() {
    // ignore: todo
    // TODO: implement initState
    super.initState();
    selectedRadio = -1;
    getCurrentUser();
  }

  @override
  void dispose() {
    // ignore: todo
    // TODO: implement dispose
    _timer.cancel();
    super.dispose();
  }

  void getCurrentUser() async {
    try {
      final user = _auth.currentUser;

      if (user != null) {
        loggedInUser = user;

        getDoctorsData();

        getData();
        _timer = Timer.periodic(Duration(seconds: 5), (Timer t) => checkBpm());
        getSubscribedDoctor();
      }
    } catch (e) {
      print(e);
    }
  }

  void checkBpm() {
    if ((int.parse(bpm) < 65 && int.parse(bpm) != 0) ||
        (int.parse(bpm) > 150 && int.parse(bpm) != 0)) {
      showAlertDialog(context);
    } else if (int.parse(op) == 0) {
      print("heart beat is 0");
    } else {
      print("heart rate is working smoothly");
    }
  }

  void getData() async {
    _fireStore
        .collection("usersData")
        .doc(loggedInUser.email)
        .snapshots()
        .listen((data) {
      setState(() {
        bpm = data["userBpm"];
      });
      checkBpm();
    });
  }

  void getDoctorsData() async {
    _fireStore
        .collection("usersData")
        .where("role", isEqualTo: "doctor")
        .snapshots()
        .listen((data) {
      for (int i = 0; i < data.size; i++) {
        doctors.add(data.docs[i]["email"]);
      }
      print(doctors);
    });
  }

  void getSubscribedDoctor() async {
    _fireStore
        .collection("usersData")
        .doc(loggedInUser.email)
        .snapshots()
        .listen((data) {
      subscribedDoctor = data.data()["subscribed to"];
      for (int i = 0; i < doctors.length; i++) {
        if (doctors[i] == subscribedDoctor) {
          setSelectedRadio(i);
        }
      }
    });
  }

  void postData() async {
    // checkBpm();
    print(op);
    await _fireStore
        .collection("usersData")
        .doc(loggedInUser.email)
        .update({"userBpm": op});
  }

  // void checkBpm() {
  //   if (int.parse(op.trim()) > 150 ||
  //       int.parse(op.trim()) < 60 ||
  //       int.parse(op.trim()) != 0) {
  //     showAlertDialog(context);
  //   }
  // }

  void makeSubscription(val) async {
    await _fireStore
        .collection("usersData")
        .doc(loggedInUser.email)
        .update({"subscribed to": doctors[val]});
  }

  void bpmIncreaseTo150() {
    setState(() {
      op = 150.toString();
    });
    showAlertDialog(context);
  }

  showAlertDialog(BuildContext context) {
    // set up the buttons
    Widget cancelButton = FlatButton(
      child: Text("No"),
      onPressed: () async {
        await _fireStore
            .collection("usersData")
            .doc(loggedInUser.email)
            .update({"makeContact": false});
        Navigator.pop(context);
      },
    );
    Widget continueButton = FlatButton(
      child: Text("Yes"),
      onPressed: () async {
        await _fireStore
            .collection("usersData")
            .doc(loggedInUser.email)
            .update({"makeContact": true});
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Alert"),
      content:
          Text("Do you want to request a call from your subscribed doctor?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    postData();
    return PickupLayout(
        scaffold: Scaffold(
      body: Background(
          child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Welcome",
              style: TextStyle(fontSize: 50.0, fontWeight: FontWeight.w100),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.fromLTRB(15, 20, 0, 0),
                  child: FlatButton(
                    onPressed: isConnectButtonEnabled ? _connect : null,
                    child: Text("Connect HC-05"),
                    color: Colors.greenAccent,
                    disabledColor: Colors.grey,
                  ),
                ),
                SizedBox(
                  width: 25,
                ),
                Container(
                  padding: EdgeInsets.fromLTRB(0, 20, 0, 0),
                  child: FlatButton(
                    onPressed: isDisConnectButtonEnabled ? _disconnect : null,
                    child: Text("Disconnect HC-05"),
                    color: Colors.redAccent,
                    disabledColor: Colors.grey,
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  "$bpm",
                  style: TextStyle(fontSize: 34, color: Colors.red),
                  textAlign: TextAlign.center,
                ),
                SizedBox(
                  height: 10,
                ),
              ],
            ),
            RoundedButton(
              text: "Subscribe to a Doctor",
              color: kPrimaryLightColor,
              textColor: Colors.black,
              press: () {
                showDialog<void>(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        contentPadding: EdgeInsets.all(0),
                        title: Text("Subscribe to any doctor"),
                        content: StatefulBuilder(builder:
                            (BuildContext context, StateSetter setState) {
                          return ListView.builder(
                              shrinkWrap: true,
                              itemCount: doctors.length,
                              itemBuilder: (BuildContext context, int index) {
                                return RadioListTile(
                                  value: index,
                                  title: Text(doctors[index]),
                                  groupValue: selectedRadio,
                                  onChanged: (value) async {
                                    setState(() => setSelectedRadio(value));

                                    makeSubscription(value);
                                  },
                                );
                              });
                        }),
                      );
                    });
              },
            ),
            SizedBox(
              height: 10,
            ),
            RoundedButton(
              text: "Log out",
              press: () {
                _auth.signOut();
                Navigator.pop(context);
              },
            ),
            SizedBox(
              height: 10,
            ),
            RoundedButton(
              text: "Increase BPM to 150",
              press: () {
                bpmIncreaseTo150();
              },
            ),
            SizedBox(
              height: 10,
            ),
            RoundedButton(
              text: "My Subscriptions",
              press: () async {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => subscribedChat()));
              },
            ),
          ],
        ),
      )),
    ));
  }
}
