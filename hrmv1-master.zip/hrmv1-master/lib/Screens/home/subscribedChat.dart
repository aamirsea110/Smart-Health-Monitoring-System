import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Login/components/background.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_auth/Screens/home/chat.dart';
import 'package:flutter_auth/models/customUser.dart';
import 'package:flutter_auth/Screens/callscreens/pickup/pickup_layout.dart';

// ignore: camel_case_types
class subscribedChat extends StatefulWidget {
  subscribedChat({Key key}) : super(key: key);

  @override
  _subscribedChatState createState() => _subscribedChatState();
}

// ignore: camel_case_types
class _subscribedChatState extends State<subscribedChat> {
  final _fireStore = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;
  User loggedInUser;
  String doctorToChat;
  CustomUser user;

  var doctors = [];
  @override
  void initState() {
    super.initState();
    getCurrentUser();
  }

  void getCurrentUser() async {
    try {
      final user = _auth.currentUser;

      if (user != null) {
        loggedInUser = user;
        getDoctorsData();
      }
    } catch (e) {
      print(e);
    }
  }

  void getDoctorsData() async {
    _fireStore
        .collection("usersData")
        .where("email", isEqualTo: loggedInUser.email)
        .snapshots()
        .listen((data) {
      for (int i = 0; i < data.size; i++) {
        setState(() {
          doctors.add(data.docs[i]["subscribed to"]);
          doctorToChat = data.docs[i]["subscribed to"];

          print(data.docs[i]["subscribed to"]);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return PickupLayout(
        scaffold: Scaffold(
      body: Background(
          child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ListView.builder(
                shrinkWrap: true,
                itemCount: doctors.length,
                itemBuilder: (BuildContext context, int index) {
                  return new Column(
                    children: <Widget>[
                      new ListTile(
                          title: Text(doctors[index]),
                          trailing: IconButton(
                              icon: Icon(Icons.message),
                              onPressed: () {
                                user = CustomUser(email: doctorToChat);
                                print(user.email + "hello");
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Chat(
                                              chatRoomId: doctorToChat +
                                                  "_" +
                                                  loggedInUser.email,
                                              myEmail: loggedInUser.email,
                                              email2: doctorToChat,
                                              receiver: user,
                                            )));
                              })),
                      new Divider(
                        height: 2.0,
                      ),
                    ],
                  );
                }),
          ],
        ),
      )),
    ));
  }
}
