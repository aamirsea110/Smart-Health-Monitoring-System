import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Signup/components/patient_signup.dart';

class SignUpScreenPatient extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}
