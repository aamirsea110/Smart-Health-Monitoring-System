import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_auth/models/customUser.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class UserProvider with ChangeNotifier {
  CustomUser _user;

  CustomUser get getUser => _user;

  void refreshUser() async {
    CustomUser user = await getUserDetails();
    _user = user;
    notifyListeners();
  }
}

Future<User> getCurrentUser() async {
  User currentUser;
  currentUser = await FirebaseAuth.instance.currentUser;
  return currentUser;
}

Future<CustomUser> getUserDetails() async {
  User currentUser = await getCurrentUser();

  DocumentSnapshot documentSnapshot = await FirebaseFirestore.instance
      .collection("usersData")
      .doc(currentUser.uid)
      .get();

  return CustomUser.fromMap(documentSnapshot.data());
}
