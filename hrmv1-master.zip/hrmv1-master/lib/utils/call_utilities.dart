import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/callscreens/call_screen_voice.dart';
import 'package:flutter_auth/models/call.dart';
import 'package:flutter_auth/models/customUser.dart';
import 'package:flutter_auth/resources/call_methods.dart';
import 'package:flutter_auth/screens/callscreens/call_screen_video.dart';

class CallUtils {
  static final CallMethods callMethods = CallMethods();

  static dialVoice({CustomUser from, CustomUser to, context}) async {
    Call call = Call(
      callerId: from.email,
      callerName: from.email,
      receiverId: to.email,
      receiverName: to.email,
      channelId: Random().nextInt(1000).toString(),
      isVideo: false,
    );

    bool callMade = await callMethods.makeCall(call: call);

    call.hasDialled = true;

    if (callMade) {
      Navigator.pop(context);
      Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CallScreenVoice(call: call),
          ));
    }
  }

  static dialVideo({CustomUser from, CustomUser to, context}) async {
    Call call = Call(
      callerId: from.email,
      callerName: from.email,
      receiverId: to.email,
      receiverName: to.email,
      channelId: Random().nextInt(1000).toString(),
      isVideo: true,
    );

    bool callMade = await callMethods.makeCall(call: call);

    call.hasDialled = true;

    if (callMade) {
      Navigator.pop(context);
      Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CallScreenVideo(call: call),
          ));
    }
  }
}
